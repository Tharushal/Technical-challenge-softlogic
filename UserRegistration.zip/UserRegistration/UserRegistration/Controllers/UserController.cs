﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using UserRegistration.Models;

namespace UserRegistration.Controllers
{
    public class UserController : Controller
    {
        DbModels dbModel = new DbModels();
        [HttpGet]
        public ActionResult AddOrEdit(int id=0)
        {
            Customer userModel = new Customer();
            return View(userModel);
        }

        [HttpPost]
        public ActionResult AddOrEdit(Customer userModel)
        {
            Customer cus = new Customer();
            if(ModelState.IsValid)
            {
                cus.ID = userModel.ID;
                cus.Name = userModel.Name;
                cus.Address = userModel.Address;
                cus.PhoneNumber = userModel.PhoneNumber;
                cus.Email = userModel.Email;
                   
                if (dbModel.Customers.Any(x => x.Name == userModel.Name))
                {
                    ViewBag.DuplicateMessage = "Customer already exist.";
                    return View("AddOrEdit", userModel);
                }
                if(userModel.ID==0)
                {
                    dbModel.Customers.Add(cus);
                    dbModel.SaveChanges();
                }
                else
                {
                    dbModel.Entry(cus).State = EntityState.Modified;
                    dbModel.SaveChanges();
                }                   
            ModelState.Clear();
            }
            ViewBag.SuccessMessage = "Registration Successful.";
            return View("AddOrEdit", new Customer());
        }

        public ActionResult GetCustomers(string searching)
        {
            DbModels dbModel = new DbModels();
            if (searching == null)
            {
                var cust = dbModel.Database.SqlQuery<Customer>("ViewAllCustomers").ToList();
                return View(cust);
            }
            else
            {
                return View(dbModel.Customers.Where(x => x.Name.StartsWith(searching)).ToList());
            }
        }

        public ActionResult Edit(Customer obj)
        {
            if(obj!=null)
            {
                return View(obj);
            }
            else
            {
                return View();
            }
        }
	}
}